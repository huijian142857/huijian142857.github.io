﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

public class BuildTool {

    static bool isDevelopment = true;

    static string GetExportPath (BuildTarget platform) {
        string basePath = Path.GetFullPath("./" + ResourceLoader.BundlesDirName);
        string path = basePath + "/" + ResourceLoader.GetBuildPlatformName(platform.ToString())+ "/";
        if (!Directory.Exists (path)) {
            Directory.CreateDirectory (path);
        }
        return path;
    }

    static void BuildAssetBundles (BuildTarget platform) {
        if (EditorApplication.isPlaying) {
            Debug.LogError ("Cannot build in playing mode!");
            return;
        }
        MakeAssetBundleNames ();
        string outputPath = GetExportPath (platform);
        Debug.Log ("AssetBundle_" + platform + " start build to:" + outputPath);
        BuildPipeline.BuildAssetBundles (outputPath, BuildAssetBundleOptions.ChunkBasedCompression, platform);
    }

    [MenuItem("Tool/AssetBundle Build")]
    static void BuildAssetBundlesForAndroid () {
        BuildAssetBundles (EditorUserBuildSettings.activeBuildTarget);
    }

    [MenuItem("Tool/AssetBundle Make Names")]
    static void MakeAssetBundleNames() {
        var dir = "Assets/" + ResourceLoader.AssetBundleBuildDir + "/";
        // Check marked asset bundle whether real
        foreach (var assetGuid in AssetDatabase.FindAssets("")) {
            var assetPath = AssetDatabase.GUIDToAssetPath(assetGuid);
            var assetImporter = AssetImporter.GetAtPath(assetPath);
            var bundleName = assetImporter.assetBundleName;
            if (string.IsNullOrEmpty(bundleName)) {
                continue;
            }
            if (!assetPath.StartsWith(dir)) {
                assetImporter.assetBundleName = null;
            }
        }
        // set BundleResources's all bundle name
        foreach (var filepath in Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories)) {
            if (filepath.EndsWith(".meta"))
                continue;
            if (filepath.EndsWith (".DS_Store"))
                continue;

            var importer = AssetImporter.GetAtPath(filepath);
            if (importer == null) {
                Debug.LogError("Not found:" + filepath);
                continue;
            }
            var bundleName = filepath.Substring(dir.Length, filepath.Length - dir.Length);
            importer.assetBundleName = bundleName + ResourceLoader.AssetBundleExt;
        }
        Debug.Log("Make all asset name successs!");
    }

    [MenuItem("Tool/Build APK")]
    static void Build () {
        if (EditorApplication.isPlaying) {
            Debug.LogError ("Cannot build in playing mode!");
            return;
        }
        BuildTarget buildTarget = BuildTarget.Android;
        if (EditorUserBuildSettings.activeBuildTarget != buildTarget) {
            Debug.LogError ("Please switch to Android Platform first!");
            return;
        }

        // 压缩AssetBundle文件，放入StreamingAssets文件夹
        string sourceDir = GetExportPath (buildTarget);
        string outputDir = Application.streamingAssetsPath + "/";
        string outputFile = outputDir + ResourceLoader.GetBuildPlatformName(buildTarget.ToString()) + ResourceLoader.AssetBundleArchiveExt;
        if (!Directory.Exists (sourceDir)) {
            Debug.LogError ("Compress Failed --- Source Dir not exist:" + sourceDir);
            return;
        }
        if (!Directory.Exists (outputDir)) {
            Directory.CreateDirectory (outputDir);
        }
        Debug.Log ("Start compress asset bundles to zip file:" + outputFile);
        ResourceLoader.CompressDirectory (sourceDir, outputFile);

        // 开始打包
        BuildPlayerOptions opt = new BuildPlayerOptions ();
        opt.scenes = GetScenePaths ();
        string basePath = Path.GetFullPath ("./" + ResourceLoader.BuildDirName + "/");
        if (!Directory.Exists (basePath)) {
            Directory.CreateDirectory (basePath);
        }
        opt.locationPathName = basePath + PlayerSettings.productName + ".apk";
        opt.target = buildTarget;
        opt.options = isDevelopment ? (BuildOptions.Development | BuildOptions.AllowDebugging) : BuildOptions.None;
        BuildPipeline.BuildPlayer (opt);

        // 打包完成，清理压缩文件
        if (File.Exists (outputFile)) {
            File.Delete(outputFile);
        }
        Debug.Log ("Build apk to:" + opt.locationPathName);
    }

    private static string[] GetScenePaths()
    {
        string[] scenes = new string[EditorBuildSettings.scenes.Length];
        for (int i = 0; i < scenes.Length; i++)
        {
            scenes[i] = EditorBuildSettings.scenes[i].path;
        }
        return scenes;
    }
}
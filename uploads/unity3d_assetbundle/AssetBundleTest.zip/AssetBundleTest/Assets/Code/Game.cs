﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;

public class Game : MonoBehaviour {

    public Canvas canvas;

    public static Game Instance;

    void Awake () {
        Instance = this;
    }

	void Start () {
        if (!Application.isEditor) {
            AssetBundleManifest bundleManifest = ResourceLoader.Instance.GetRootManifest ();
            if (bundleManifest == null) {
                // 不存在，第一次解压 asset bundle
                Debug.LogWarning ("Bundle Manifest not exist ... start first decompress ...");
                ResourceLoader.Instance.DecompressAssetBundle (() => {
                    ResourceLoader.Instance.GetRootManifest ();
                    DoNext ();
                });
            } else {
                DoNext ();
            }
        } else {
            DoNext ();
        }
	}
	
	void Update () {
		
	}

    void DoNext () {
        ResourceLoader.Instance.LoadAsset ("model/Sphere.prefab", (Object result) => {
            if (result != null) {
                Instantiate(result);
            }
        });
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;
using System.IO;
using System.IO.Compression;
using System;

public delegate void LoaderCallback (Object resultObj);

public class ResourceLoader {

    public const string AssetBundleBuildDir = "BundleResources";
    public const string BundlesDirName = "Bundles";
    public const string AssetBundleExt = ".ab";
    public const string BuildDirName = "Build";
    public const string AssetBundleArchiveExt = ".zip";

    private static ResourceLoader _instance;
    public static ResourceLoader Instance {
        get { 
            if (_instance == null) {
                _instance = new ResourceLoader ();
            }
            return _instance;
        }
    }

    private AssetBundleManifest bundleMainfest;

    private static string _editorActiveBuildTarget;
    public static string EditorActiveBuildTarget {
        get {
            if (Application.isPlaying && !string.IsNullOrEmpty (_editorActiveBuildTarget)) {
                return _editorActiveBuildTarget;
            }
            // UnityEditor.EditorUserBuildSettings.activeBuildTarget
            var assemblies = System.AppDomain.CurrentDomain.GetAssemblies ();
            foreach (var a in assemblies) {
                if (a.GetName ().Name == "UnityEditor") {
                    var lockType = a.GetType ("UnityEditor.EditorUserBuildSettings");
                    var p = lockType.GetProperty ("activeBuildTarget");
                    var em = p.GetGetMethod ().Invoke (null, new object[] { }).ToString ();
                    _editorActiveBuildTarget = em;
                    return _editorActiveBuildTarget;
                }
            }
            return null;
        }
    }

    private static string _bundleBasePath;
    public static string BundleBasePath {
        get {
            if (_bundleBasePath == null) {
                _bundleBasePath = string.Format ("{0}/{1}/{2}/", Application.persistentDataPath, BundlesDirName, GetBuildPlatformName ());
            }
            return _bundleBasePath;
        }
    }

    public static string GetBuildPlatformName(string buildTarget)
    {
        string buildPlatformName = "";
        switch (buildTarget)
        {
        case "StandaloneOSXIntel":
        case "StandaloneOSXIntel64":
        case "StandaloneOSXUniversal":
            buildPlatformName = "MacOS";
            break;
        case "StandaloneWindows":
        case "StandaloneWindows64":
            buildPlatformName = "Windows";
            break;
        case "Android":
            buildPlatformName = "Android";
            break;
        case "iOS":
            buildPlatformName = "iOS";
            break;
        default:
            Debug.Assert(false);
            break;
        }
        return buildPlatformName;
    }

    /// <summary>
    /// Different platform's assetBundles is incompatible.
    /// CosmosEngine put different platform's assetBundles in different folder.
    /// Here, get Platform name that represent the AssetBundles Folder.
    /// </summary>
    public static string GetBuildPlatformName()
    {
        string buildPlatformName = "";

        if (Application.isEditor)
        {
            buildPlatformName = GetBuildPlatformName (EditorActiveBuildTarget);
        }
        else
        {
            switch (Application.platform)
            {
            case RuntimePlatform.OSXPlayer:
                buildPlatformName = "MacOS";
                break;
            case RuntimePlatform.Android:
                buildPlatformName = "Android";
                break;
            case RuntimePlatform.IPhonePlayer:
                buildPlatformName = "iOS";
                break;
            case RuntimePlatform.WindowsPlayer:
                buildPlatformName = "Windows";
                break;
            default:
                Debug.Assert(false);
                break;
            }
        }
        return buildPlatformName;
    }

    public AssetBundleManifest GetRootManifest () {
        if (bundleMainfest != null)
            return bundleMainfest;
        
        string abPath = BundleBasePath + GetBuildPlatformName();
        Debug.Log ("Load total Manifest from:" + abPath);
        AssetBundle bundle = AssetBundle.LoadFromFile (abPath);
        if (bundle != null) {
            bundleMainfest = bundle.LoadAsset ("AssetBundleManifest") as AssetBundleManifest;
        } else {
            Debug.LogWarning ("Load total Manifest failed");
        }
        return bundleMainfest;
    }

    public static void CompressDirectory(string sInDir, string sOutFile) {
        ZipStorer zip = ZipStorer.Create (sOutFile, "");
        string[] sFiles = Directory.GetFiles (sInDir, "*.*", SearchOption.AllDirectories);
        int iDirLen = sInDir [sInDir.Length - 1] == Path.DirectorySeparatorChar ? sInDir.Length : sInDir.Length + 1;
        foreach (string path in sFiles) {
            string sRelativePath = path.Substring (iDirLen);
            zip.AddFile (ZipStorer.Compression.Deflate, path, sRelativePath, "");
        }
        zip.Close ();
    }

    public static bool DecompressToDirectory(string sInFile, string sOutDir) {
        ZipStorer zip = ZipStorer.Open (sInFile, FileAccess.Read);
        List<ZipStorer.ZipFileEntry> dir = zip.ReadCentralDir ();
        bool result = true;
        foreach (ZipStorer.ZipFileEntry entry in dir) {
            string path = Path.Combine (sOutDir, entry.FilenameInZip);
            if (!zip.ExtractFile (entry, path)) {
                result = false;
                break;
            }
        }
        zip.Close ();
        return result;
    }

    public static bool DecompressToDirectory(Stream sInStream, string sOutDir) {
        ZipStorer zip = ZipStorer.Open (sInStream, FileAccess.Read);
        List<ZipStorer.ZipFileEntry> dir = zip.ReadCentralDir ();
        bool result = true;
        foreach (ZipStorer.ZipFileEntry entry in dir) {
            string path = Path.Combine (sOutDir, entry.FilenameInZip);
            if (!zip.ExtractFile (entry, path)) {
                result = false;
                break;
            }
        }
        zip.Close ();
        return result;
    }

    public void DecompressAssetBundle (Action onFinish) {
        Game.Instance.StartCoroutine (DoDecompress (onFinish));
    }

    private IEnumerator DoDecompress (Action onFinish) {
        string archiveBundlePath = Path.Combine (Application.streamingAssetsPath, GetBuildPlatformName ()) + AssetBundleArchiveExt;
        string destPath = BundleBasePath;
        Debug.Log ("Decompress From:" + archiveBundlePath);
        Debug.Log ("Decompress To:" + destPath);
        WWW wwwFile = new WWW (archiveBundlePath);
        yield return wwwFile;
        bool result = DecompressToDirectory (new MemoryStream(wwwFile.bytes), destPath);
        Debug.Log ("decompress success:" + result);
        onFinish ();
    }

    public void LoadAsset (string path, LoaderCallback onFinish) {
        #if UNITY_EDITOR
        string objPath = "Assets/" + AssetBundleBuildDir + "/" + path;
        Object obj = UnityEditor.AssetDatabase.LoadAssetAtPath (objPath, typeof(UnityEngine.Object));
        onFinish (obj);
        #else
        Game.Instance.StartCoroutine (DoLoadAsset (path, onFinish));
        #endif
    }

    private IEnumerator DoLoadAsset (string path, LoaderCallback onFinish) {
        Debug.Assert (bundleMainfest != null, "bundleMainfest is null");
        string relativeUrl = path.ToLower() + AssetBundleExt;
        var bundleDict = LoadAssetBundle (relativeUrl);
        AssetBundle bundle = bundleDict [relativeUrl];
        string assetName = Path.GetFileName (path);
        Debug.Log ("LoadAsset Name:" + assetName);
        Object obj = bundle.LoadAsset (assetName);
        foreach (var v in bundleDict) {
            v.Value.Unload (false);
        }
        onFinish (obj);
        yield return null;
    }

    private Dictionary<string, AssetBundle> LoadAssetBundle (string path) {
        Dictionary<string, AssetBundle> bundleDict = new Dictionary<string, AssetBundle> ();
        foreach (var v in bundleMainfest.GetAllDependencies(path)) {
            LoadAssetBundle (v);
        }
        string abPath = BundleBasePath + path;
        Debug.Log ("LoadAssetBundle From:" + abPath);
        AssetBundle ab = AssetBundle.LoadFromFile (abPath);
        bundleDict.Add (path, ab);
        return bundleDict;
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Algorithms;

public class Test : MonoBehaviour {

    public GameObject ObstaclePrefab;
    public GameObject NodePrefab;

    private int width;
    private int height;

    private byte[,] grid;

	// Use this for initialization
	void Start () {
        width = 32;
        height = 20;
        int newWidth = GetNearestPowOfTwo(width);
        int newHeight = GetNearestPowOfTwo(height);
        // pathFinderFast 速度更快，但要求地图大小必须是2的次方
        grid = new byte[newWidth, newHeight];
        ResetByteArray(grid);
        //var pathfinder = new PathFinder(grid);
        var pathfinder = new PathFinderFast(grid);
        pathfinder.SearchLimit = 500000;
        pathfinder.Formula = HeuristicFormula.Euclidean;
        pathfinder.Diagonals = true;
        pathfinder.HeavyDiagonals = true;
        pathfinder.PunishChangeDirection = false;

        //设置不可走区域
        List<Vector2Int> obstacles = new List<Vector2Int>() {
            new Vector2Int (15, 16), new Vector2Int (16, 16), new Vector2Int (17, 16), new Vector2Int(18, 16), new Vector2Int(19, 16), new Vector2Int(20, 16),
            new Vector2Int (15, 3), new Vector2Int (16, 3), new Vector2Int (17, 3), new Vector2Int (18, 3), new Vector2Int (19, 3), new Vector2Int (20, 3),
            new Vector2Int (15, 15), new Vector2Int (15, 14), new Vector2Int (15, 13), new Vector2Int (15, 12), new Vector2Int (15, 11),
            new Vector2Int (15, 4), new Vector2Int (15, 5), new Vector2Int (15, 6), new Vector2Int (15, 7), new Vector2Int (15, 8),
            new Vector2Int (16, 10), new Vector2Int (17, 10), new Vector2Int (18, 10), new Vector2Int (19, 9), new Vector2Int (20, 8),
        };
        foreach (var v in obstacles) {
            grid[v.x, v.y] = 0;
            Instantiate (ObstaclePrefab, GetPosition (v.x, v.y), Quaternion.identity);
        }

        //寻路测试
        var startPoint = new Vector2Int(3, 8);
        var endPoint = new Vector2Int(18, 13);
        var points = pathfinder.FindPath (startPoint, endPoint);
        if (points == null)
        {
            Debug.Log("find path failed");
            return;
        }
        Debug.Log(string.Format("find path from {0} to {1} costTime: {2}", startPoint, endPoint, pathfinder.CompletedTime));

        List<Vector2Int> resultPoints = new List<Vector2Int>();
        for (int i = 0; i < points.Count; i++)
        {
            var point = points[i];
            resultPoints.Add(new Vector2Int(point.X, point.Y));
        }
        
        //平滑 -- 去除同一直线上的点
        if (resultPoints.Count >= 3)
        {
            var wayPoints = new List<Vector2Int>();
            var directionOld = Vector2Int.zero;
            for (int i = 0; i < resultPoints.Count - 1; i++)
            {
                var directionNew = new Vector2Int(resultPoints[i + 1].x - resultPoints[i].x, resultPoints[i + 1].y - resultPoints[i].y);
                if (directionNew != directionOld)
                {
                    wayPoints.Add(resultPoints[i]);
                }
                directionOld = directionNew;
            }
            var lastPoint = resultPoints[resultPoints.Count - 1];
            if (wayPoints[wayPoints.Count - 1] != lastPoint)
            {
                wayPoints.Add(lastPoint);
            }
            resultPoints = wayPoints;
        }
        
        //平滑 -- 去除多余的拐点
        for (int i = resultPoints.Count - 1; i >= 0; i--)
        {
            for (int j = 0; j <= i-1; j++)
            {
                if (CanCross(resultPoints[i], resultPoints[j]))
                {
                    for (int k = i-1; k > j; k--)
                    {
                        resultPoints.RemoveAt(k);
                    }
                    i = j;
                    break;
                }
            }
        }

        foreach (var v in resultPoints) {
            Instantiate (NodePrefab, GetPosition (v.x, v.y), Quaternion.identity);
        }
	}

    /// <summary>
    /// 两个点之间是否有障碍物
    /// </summary>
    public bool CanCross(Vector2Int start, Vector2Int end)
    {
        if (!IsWalkable(start) || !IsWalkable(end)) return false;
        if (start == end) return IsWalkable(start);

        bool greaterWidth = Mathf.Abs(start.x - end.x) > Mathf.Abs(start.y - end.y);
        float size = 1;
        float stepX = end.x > start.x ? size : -size;
        float stepY = end.y > start.y ? size : -size;
        float nowX = start.x + Mathf.Abs(stepX / 2);
        float nowY = start.y + Mathf.Abs(stepY / 2);

        if (greaterWidth)
        {
            float deltaY = size * (end.y - start.y) / Mathf.Abs(end.x - start.x);
            int count = Mathf.Abs(start.x - end.x);
            while (count >= 0)
            {
                if (!CheckWalkable(nowX, nowY)) return false;
                nowX += stepX;
                nowY += deltaY;
                count--;
            }
        }
        else
        {
            float deltaX = size * (end.x - start.x) / Mathf.Abs(end.y - start.y);
            int count = Mathf.Abs(start.y - end.y);
            while (count >= 0)
            {
                if (!CheckWalkable(nowX, nowY)) return false;
                nowX += deltaX;
                nowY += stepY;
                count--;
            }
        }

        return true;
    }

    private bool CheckWalkable(float nx, float ny)
    {
        var point = new Vector2Int(Mathf.FloorToInt(nx), Mathf.FloorToInt(ny));
        if (!IsWalkable(point)) return false;

        int[,] mDirection = new int[8, 2] { { 0, -1 }, { 1, 0 }, { 0, 1 }, { -1, 0 }, { 1, -1 }, { 1, 1 }, { -1, 1 }, { -1, -1 } };
        for (int i = 0; i < 8; i++)
        {
            var mX = point.x + mDirection[i, 0];
            var mY = point.y + mDirection[i, 1];
            if (!IsWalkable(new Vector2Int(mX, mY)))
            {
                return false;
            }
        }

        return true;
    }

    public bool IsWalkable(Vector2Int point)
    {
        if (grid == null) return false;

        if (point.x >= grid.GetUpperBound(0) || point.y >= grid.GetUpperBound(1))
        {
            return false;
        }

        return grid[point.x, point.y] > 0;
    }

    public int GetNearestPowOfTwo(int num)
    {
        return (int)Mathf.Pow(2, Mathf.Ceil(Mathf.Log(num, 2)));
    }

    void ResetByteArray(byte[,] array)
    {
        for (int y = 0; y < array.GetUpperBound(1); y++)
        {
            for (int x = 0; x < array.GetUpperBound(0); x++)
            {
                array[x, y] = 1;
            }
        }
    }

    Vector3 GetPosition(int x, int y) {
        float offsetX = -width * 0.5f + 0.5f;
        float offsetY = -height * 0.5f + 0.5f;
        return new Vector3 (x + offsetX, y + offsetY, 0);
    }
}
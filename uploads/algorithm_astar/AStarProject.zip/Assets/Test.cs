﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour {

    public GameObject ObstaclePrefab;
    public GameObject NodePrefab;

    private AStarPathfinder pathfinder;
    private int width;
    private int height;

	// Use this for initialization
	void Start () {
        width = 32;
        height = 20;
        pathfinder = new AStarPathfinder (width, height);

        //设置不可走区域
        List<IntVector2> obstacles = new List<IntVector2> () {
            new IntVector2 (15, 16), new IntVector2 (16, 16), new IntVector2 (17, 16), new IntVector2(18, 16), new IntVector2(19, 16), new IntVector2(20, 16),
            new IntVector2 (15, 3), new IntVector2 (16, 3), new IntVector2 (17, 3), new IntVector2 (18, 3), new IntVector2 (19, 3), new IntVector2 (20, 3),
            new IntVector2 (15, 15), new IntVector2 (15, 14), new IntVector2 (15, 13), new IntVector2 (15, 12), new IntVector2 (15, 11),
            new IntVector2 (15, 4), new IntVector2 (15, 5), new IntVector2 (15, 6), new IntVector2 (15, 7), new IntVector2 (15, 8),
            new IntVector2 (16, 10), new IntVector2 (17, 10), new IntVector2 (18, 10), new IntVector2 (19, 9), new IntVector2 (20, 8),
        };
        foreach (var v in obstacles) {
            pathfinder.SetWalkable (v, false);
            Instantiate (ObstaclePrefab, GetPosition (v.x, v.y), Quaternion.identity);
        }

        //寻路测试
        List<IntVector2> results = pathfinder.FindPath (new IntVector2(3, 8), new IntVector2(18,13));
        foreach (var v in results) {
            Instantiate (NodePrefab, GetPosition (v.x, v.y), Quaternion.identity);
        }
	}

    Vector3 GetPosition(int x, int y) {
        float offsetX = -width * 0.5f + 0.5f;
        float offsetY = -height * 0.5f + 0.5f;
        return new Vector3 (x + offsetX, y + offsetY, 0);
    }
}
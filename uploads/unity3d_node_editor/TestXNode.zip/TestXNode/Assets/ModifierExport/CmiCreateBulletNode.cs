﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

[CreateNodeMenu("mtCharacter/cmiCreateBullet")]
[NodeWidth(250)]
public class CmiCreateBulletNode : ModifierNode
{
    public override ModifierType GetModifierType()
    {
        return ModifierType.mtCharacter;
    }
}
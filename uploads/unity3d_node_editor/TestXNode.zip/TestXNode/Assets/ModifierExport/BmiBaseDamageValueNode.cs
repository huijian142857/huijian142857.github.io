﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

[CreateNodeMenu("mtBullet/bmiBaseDamageValue")]
[NodeWidth(250)]
public class BmiBaseDamageValueNode : ModifierNode
{
    public BulletDamageType damageType;

    public override ModifierType GetModifierType()
    {
        return ModifierType.mtBullet;
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

[CreateNodeMenu("mtBullet/bmiElementDamageValueNode")]
[NodeWidth(280)]
public class BmiElementDamageValueNode : ModifierNode
{
    public override ModifierType GetModifierType()
    {
        return ModifierType.mtBullet;
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using XNode;

[NodeTint("#FFEC8B")]
public abstract class ModifierNode : Node
{
    public string Description;

    [Input] public Connection input;
    [Output] public Connection nextNode;

    public abstract ModifierType GetModifierType();
}

[System.Serializable]
public class Connection
{

}

public enum ModifierType
{
    mtInvalid,
    mtCharacter,
    mtBullet,
}

public enum BulletDamageType
{
    mtInvalid,
    mtDirect,
    mtPhysics,
}
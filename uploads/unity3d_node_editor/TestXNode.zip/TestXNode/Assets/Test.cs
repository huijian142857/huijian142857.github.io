﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour {

	// Use this for initialization
	void Start () {
        ModifierGraph mg = UnityEditor.AssetDatabase.LoadAssetAtPath<ModifierGraph>("Assets/ModifierGraph_001.asset");
        foreach (var node in mg.nodes)
        {
            var nextNodePort = node.GetOutputPort("nextNode");
            if (nextNodePort != null && nextNodePort.IsConnected)
            {
                var connection = nextNodePort.GetConnection(0);
                ModifierNode cNode = node as ModifierNode;
                ModifierNode mNode = connection.node as ModifierNode;
                Debug.LogWarning("current: " + cNode.Description + " next: " + mNode.Description);
            }
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

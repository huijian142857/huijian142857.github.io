﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ItemTable : BaseTable
{
    public List<ItemElement> DataList = new List<ItemElement>();

    [HideInInspector]
    public Dictionary<int, ItemElement> dict = new Dictionary<int, ItemElement>();

    public override void Init()
    {
        base.Init();

        foreach (var v in DataList)
        {
            if (dict.ContainsKey(v.ID))
            {
                Debug.LogError("Table Init error with same Id: " + v.ID);
                continue;
            }
            dict.Add(v.ID, v);
        }
    }
}

public enum ItemType
{
    Invalid = 0,
    Coin = 1,
    Crystal = 2,
    Equipment = 3,
}

[Serializable]
public class ItemElement
{
    public int ID;
    public string Name;
    public bool QuickUse;
    public ItemType ItemType;
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using OfficeOpenXml;

public class ExcelTool : MonoBehaviour
{
	void Start ()
    {
        string filePath = @"D:\" + "Ite.xlsx";
        string sheetName = "Sheet1";
        GenerateExcel(filePath, sheetName);
        ReadExcel(filePath, sheetName);
	}

    private void ReadExcel(string filePath, string sheetName)
    {
        var fi = new FileInfo(filePath);

        using (var package = new ExcelPackage(fi))
        {
            ExcelWorksheet worksheet = package.Workbook.Worksheets[sheetName];
            for (int i = 2; i <= worksheet.Dimension.End.Row; i++)
            {
                Debug.Log(worksheet.Cells[i, 1].Value + "  " + worksheet.Cells[i, 2].Value + "  " + worksheet.Cells[i, 3].Value);
            }
        }
    }

    private void GenerateExcel(string filePath, string sheetName)
    {
        var fi = new FileInfo(filePath);
        if (fi.Exists)
        {
            fi.Delete();
            fi = new FileInfo(filePath);
        }
        
        using (var package = new ExcelPackage(fi))
        {
            // Add a new worksheet to the empty workbook
            ExcelWorksheet worksheet = package.Workbook.Worksheets.Add(sheetName);

            // Add the headers
            var headerRow = new List<object[]>()
            {
                new string[] { "ID", "Product", "Price" }
            };
            string headerRange = "A1:" + char.ConvertFromUtf32(headerRow.Count + 64) + "1";
            worksheet.Cells[headerRange].LoadFromArrays(headerRow);

            // Add some items
            worksheet.Cells[2, 1].Value = 1001;
            worksheet.Cells[2, 2].Value = "Hammer";
            worksheet.Cells[2, 3].Value = 4.6;

            worksheet.Cells[3, 1].Value = 1001;
            worksheet.Cells[3, 2].Value = "Hammer";
            worksheet.Cells[3, 3].Value = 4.6;

            //worksheet.Cells["E2:E4"].Formula = "C2*D2";

            // set style
            for (int r = 1; r <= worksheet.Dimension.Rows; r++)
            {
                for (int c = 1; c <= headerRow[0].Length; c++)
                {
                    worksheet.Cells[r, c].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    worksheet.Cells[r, c].Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
                }
            }

            worksheet.Calculate();
            worksheet.Cells.AutoFitColumns(0);
            package.Save();
        }

        Debug.Log("generateExcel done");
    }
}

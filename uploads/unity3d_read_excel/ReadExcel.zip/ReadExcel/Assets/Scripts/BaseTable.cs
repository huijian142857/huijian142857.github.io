﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseTable : MonoBehaviour
{
    public string TableName;
    public string ExcelPath;

    public virtual void Init() { }
}

[System.Serializable]
public class TableDataPath
{
    public string Path;
    public string TableName;
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
using OfficeOpenXml;
using System;
using System.Reflection;

[CustomEditor(typeof(BaseTable), true)]
public class BaseTableEditor : Editor
{
    public override void OnInspectorGUI()
    {
        if (GUILayout.Button("Load Excel"))
        {
            LoadExcel();
        }
        base.OnInspectorGUI();
    }

    void LoadExcel()
    {
        var currentTarget = (BaseTable)serializedObject.targetObject;
        string filePath = Application.dataPath + "/Excel/" + currentTarget.ExcelPath + ".xlsx";
        Debug.Log("filePath: " + filePath);
        var fileInfo = new FileInfo(filePath);
        using (var package = new ExcelPackage(fileInfo))
        {
            ExcelWorksheet ws = package.Workbook.Worksheets[currentTarget.TableName];
            Type tableType = currentTarget.GetType();
            FieldInfo listField = tableType.GetField("DataList");
            Type listType = listField.FieldType;
            Type elementType = listField.FieldType.GetGenericArguments()[0];
            listType.GetMethod("Clear").Invoke(listField.GetValue(currentTarget), new object[] { });

            var clientColDic = new Dictionary<int, string>();
            int colNum = GetColumnsCount(ws);
            int rowNum = GetRowsCount(ws);
            for (int i = 1; i <= colNum; i++)
            {
                Debug.Assert(ws.Cells[2, i].Value != null, "null Row:2 Col:" + i);
                if (ws.Cells[2, i].Value.ToString() != "Server")
                {
                    clientColDic.Add(i, ws.Cells[1, i].Value.ToString());
                }
            }
            Debug.Log("colNum: " + colNum + " rowNum: " + rowNum);

            for (int i = 3; i <= rowNum; i++)
            {
                object subData = Activator.CreateInstance(elementType, null);
                for (int j = 1; j <= colNum; j++)
                {
                    if (clientColDic.ContainsKey(j))
                    {
                        if (ws.Cells[i, j].Value == null || string.IsNullOrEmpty(ws.Cells[i, j].Value.ToString()))
                        {
                            Debug.LogWarning("Row " + i + " Column " + j + " is Null");
                            continue;
                        }
                        string val = ws.Cells[i, j].Value.ToString();
                        FieldInfo fi = elementType.GetField(clientColDic[j]);
                        if (fi == null)
                        {
                            Debug.LogWarning("Can not find FieldInfo " + clientColDic[j]);
                            continue;
                        }

                        if (fi.FieldType.Equals(typeof(int)))
                        {
                            Debug.Log("Property: " + fi + " int value: " + val);
                            fi.SetValue(subData, Convert.ToInt32(val));
                        }
                        else if (fi.FieldType.Equals(typeof(string)))
                        {
                            Debug.Log("Property: " + fi + " string value: " + val);
                            fi.SetValue(subData, val);
                        }
                        else if (fi.FieldType.Equals(typeof(bool)))
                        {
                            Debug.Log("Property: " + fi + " bool value: " + val);
                            fi.SetValue(subData, Convert.ToBoolean(int.Parse(val)));
                        }
                        else if (fi.FieldType.Equals(typeof(float)))
                        {
                            Debug.Log("Property: " + fi + " float value: " + val);
                            fi.SetValue(subData, Convert.ToSingle(val));
                        }
                        else if (fi.FieldType.IsEnum)
                        {
                            Debug.Log("Property: " + fi + " enum value: " + val);
                            fi.SetValue(subData, Convert.ToInt32(val));
                        }
                        else
                        {
                            Debug.LogWarning("Property: " + fi + " null value: " + val);
                        }
                    }
                }
                listType.GetMethod("Add").Invoke(listField.GetValue(currentTarget), new object[] { subData });
            }

            SaveAs_Txt(filePath, ws, rowNum, colNum);
        }

        AssetDatabase.SaveAssets();
        Debug.Log("done");
    }

    void SaveAs_Txt(string filePath, ExcelWorksheet ws, int rowNum, int colNum)
    {
        if (!filePath.EndsWith(".xlsx"))
        {
            Debug.LogError("filePath is wrong");
            return;
        }
        string targetFilePath = filePath.Replace(".xlsx", ".txt");

        using (TextWriter tw = new StreamWriter(targetFilePath, false, System.Text.Encoding.UTF8))
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder(10000);
            for (int i = 1; i <= rowNum; i++)
            {
                for (int j = 1; j <= colNum; j++)
                {
                    sb.Append(ws.Cells[i,j].Value.ToString());
                    if (j != colNum)
                    {
                        sb.Append("\t");
                    }
                }
                sb.Append("\r\n");
            }
            tw.Write(sb);
        }
    }

    void CombineExcel(TableDataPath resultDataPath, List<TableDataPath> dataPathList)
    {
        if (dataPathList.Count <= 0) return;

        var firstDataPath = dataPathList[0];
        var firstFileInfo = new FileInfo(firstDataPath.Path);
        using (var firstPackage = new ExcelPackage(firstFileInfo))
        {
            var firstSheet = firstPackage.Workbook.Worksheets[firstDataPath.TableName];
            int colNum = GetColumnsCount(firstSheet);
            int currentRow = GetRowsCount(firstSheet);

            for (int i = 1; i < dataPathList.Count; i++)
            {
                var data = dataPathList[i];
                var fileInfo = new FileInfo(data.Path);
                using (var package = new ExcelPackage(fileInfo))
                {
                    ExcelWorksheet workSheet = package.Workbook.Worksheets[data.TableName];
                    int rows = GetRowsCount(workSheet);
                    if (rows > 2)
                    {
                        var source = workSheet.Cells[3, 1, rows, colNum];
                        var target = firstSheet.Cells[currentRow + 1, 1, currentRow + rows, colNum];
                        source.Copy(target);
                        currentRow += rows;
                    }
                }
            }

            var fi = new FileInfo(resultDataPath.Path);
            if (fi.Exists)
            {
                File.SetAttributes(resultDataPath.Path, FileAttributes.Normal);
            }
            using (var package = new ExcelPackage(fi))
            {
                package.Workbook.Worksheets.Delete(resultDataPath.TableName);
                var workSheet = package.Workbook.Worksheets.Add(resultDataPath.TableName, firstSheet);
                int rowCount = GetRowsCount(workSheet);
                int colCount = GetColumnsCount(workSheet);

                for (int r = 1; r <= rowCount; r++)
                {
                    for (int c = 1; c <= colCount; c++)
                    {
                        workSheet.Cells[r, c].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        workSheet.Cells[r, c].Style.VerticalAlignment = OfficeOpenXml.Style.ExcelVerticalAlignment.Center;
                    }
                }

                package.Workbook.Worksheets.MoveToStart(resultDataPath.TableName);
                workSheet.View.TabSelected = true;
                workSheet.Calculate();
                workSheet.Cells.AutoFitColumns(0);
                package.Save();
            }
        }
    }

    int GetColumnsCount(ExcelWorksheet ws)
    {
        int count = 0;
        for (; count < ws.Dimension.Columns; count++)
        {
            object obj = ws.Cells[1, count + 1].Value;
            if (obj == null || obj.ToString() == string.Empty)
                return count;
        }
        return count;
    }

    int GetRowsCount(ExcelWorksheet ws)
    {
        int count = 0;
        for (; count < ws.Dimension.Rows; count++)
        {
            object obj = ws.Cells[count + 1, 1].Value;
            if (obj == null || obj.ToString() == string.Empty)
                return count;
        }
        return count;
    }
}

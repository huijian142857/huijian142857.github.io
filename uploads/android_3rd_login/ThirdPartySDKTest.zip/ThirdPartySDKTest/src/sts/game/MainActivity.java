package sts.game;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import sts.game.authentication.AuthenticationManager;
import sts.game.oppo.OppoClientHelper;
import android.app.Activity;
import android.os.Bundle;

public class MainActivity extends Activity {

	private ThirdPartyClientInterface m_thirdPartyClient;
	private AuthenticationManager m_authenticationManager;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		m_thirdPartyClient = OppoClientHelper.getInstance();
		if (m_thirdPartyClient != null)
		{
			m_thirdPartyClient.setMainActivity(this);
			m_thirdPartyClient.sdkInit();
		}
		
		m_authenticationManager = new AuthenticationManager(this);
	}
	
	public void authenticate(final String authenticatorId, final URL webAddress, final Map<String, String> inputParameters)
	{
		if (m_authenticationManager != null)
			m_authenticationManager.authenticate(authenticatorId, webAddress, inputParameters);
	}
	
	public void submitExtendData(final String characterId, final String characterName, final int characterLevel){
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("characterId", characterId);
		data.put("characterName", characterName);
		data.put("characterLevel", characterLevel);
		
		if (m_thirdPartyClient != null)
		{
			m_thirdPartyClient.sdkSubmitExtendData(data);
		}
	}
	
	public void onHudVisibilityChange(final boolean isVisible){
		if (m_thirdPartyClient != null)
		{
			m_thirdPartyClient.sdkShowFloatButton(isVisible);
		}
	}
	
	public UUID getGameId(){
		return UUID.fromString("123456");
	}
	
	public String getDeviceId()
	{
		return "deviceId";
	}
	
	public boolean isEnabledAuthenticationType(final String authenticationTypeId){
		if (authenticationTypeId.equals("oppo"))
			return true;
		else
			return false;
	}
	
	public void onAuthenticationCancel(){
		
	}
	
	public void onAuthenticationFailure(final String resultMessageId){
		
	}
	
	public void onAuthenticationSuccess(final UUID token){
		
	}
}

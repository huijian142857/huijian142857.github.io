package sts.game.authentication.oppo;

import sts.game.authentication.AuthenticationInterface;
import sts.game.authentication.AuthenticationRequest;
import sts.game.authentication.AuthenticationRequestCallback;
import sts.game.authentication.AuthenticationResponse;
import sts.game.authentication.Authenticator;
import sts.game.oppo.OppoClientHelper;

public class OppoAuthenticator  implements Authenticator {

	public OppoAuthenticator()
	{
	}

	@Override
	public void shutdown()
	{
	}

	@Override
	public void authenticate(final AuthenticationInterface authenticationInterface, final AuthenticationRequest request)
	{
		// save the request
		m_authenticationInterface = authenticationInterface;
		m_request = request;
		
		// call third party login method
		OppoClientHelper m_oppoSdk = OppoClientHelper.getInstance();
		m_oppoSdk.setLoginCallback(new OppoLoginCallback()
		{
			@Override
			public void onSuccess(String userId, String accessToken) {
				doAuthenticate(userId, accessToken);
			}

			@Override
			public void onFailure() {
				m_authenticationInterface.onAuthenticationCancel();
			}
		});
		m_oppoSdk.sdkLogin();
	}

	// ----------------------------------------------------------------------
	
	private void doAuthenticate(String userId, String accessToken)
	{
		m_request.updateParameter("userId", userId);
		m_request.updateParameter("token", accessToken);
		m_authenticationInterface.sendRequest(m_request, new AuthenticationRequestCallback()
		{
			public void execute(final AuthenticationResponse response)
			{
				if (response.getResult() == AuthenticationResponse.Result.R_Success)
				{
					m_authenticationInterface.onAuthenticationSuccess(response.getAuthenticationToken());
				}
				else
				{
					m_authenticationInterface.onAuthenticationFailure(response.getResultMessage());
				}
			}
		});
	}
	
	// ----------------------------------------------------------------------
	
	private AuthenticationInterface m_authenticationInterface;
	private AuthenticationRequest m_request;
	
	// ----------------------------------------------------------------------
}

package sts.game.authentication;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;

import sts.game.MainActivity;

public class GameAuthenticationInterface implements AuthenticationInterface
{
	public GameAuthenticationInterface(final MainActivity gameActivity)
	{
		m_gameActivity = gameActivity;
	}
	
	public void sendRequest(final AuthenticationRequest request, final AuthenticationRequestCallback callback)
	{
		Thread requestThread = new Thread(new Runnable()
		{
			public void run()
			{
				handleAuthenticationRequest(request, callback);
			}
		});

		requestThread.start();
	}

	public void onAuthenticationSuccess(final UUID token)
	{
		m_gameActivity.onAuthenticationSuccess(token);
	}

	public void onAuthenticationFailure(final String resultMessage)
	{
		m_gameActivity.onAuthenticationFailure(resultMessage);
	}

	public void onAuthenticationCancel()
	{
		m_gameActivity.onAuthenticationCancel();
	}

	private void handleAuthenticationRequest(final AuthenticationRequest request, final AuthenticationRequestCallback callback)
	{
		String parameters = "";
		try
		{
			final String gameId = m_gameActivity.getGameId().toString();
			if (gameId != null)
				parameters = "gameId=" + URLEncoder.encode(gameId, "UTF-8");
			else
			{
				sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to determine gameId for transmission."), callback);
				return;
			}

			final String deviceId = m_gameActivity.getDeviceId();
			if (deviceId != null)
				parameters += "&deviceId=" + URLEncoder.encode(deviceId.substring(0, Math.min(1024, deviceId.length())), "UTF-8");
			else
			{
				sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to determine deviceId for transmission."), callback);
				return;
			}

			for (final Map.Entry<String, String> parameter : request.getParameters().entrySet())
			{
				parameters += ("&" + URLEncoder.encode(parameter.getKey(), "UTF-8") + "=" + URLEncoder.encode(parameter.getValue(), "UTF-8"));
			}
		}
		catch (final UnsupportedEncodingException exception)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to encode request parameters for transmission: " + exception.toString()), callback);
			return;
		}

		final URL destination = request.getDestination();
		if (destination == null)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to complete request because no destination was specified."), callback);
			return;
		}

		final HttpURLConnection requestConnection;
		try
		{
			requestConnection = (HttpURLConnection)(destination.openConnection());
		}
		catch (final IOException exception)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to open a connection to " + destination.toString() + ": " + exception.toString()), callback);
			return;
		}

		if (requestConnection == null)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to open a Https connection to " + destination.toString() + ", or it is not an https connection."), callback);
			return;
		}

		try
		{
			requestConnection.setRequestMethod("POST");
		}
		catch (final ProtocolException exception)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to send a POST request to " + destination.toString() + ": " + exception.toString()), callback);
			return;
		}

		requestConnection.setDoOutput(true);
		requestConnection.setFixedLengthStreamingMode(parameters.getBytes().length);
		requestConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

		PrintWriter parameterWriter;
		try
		{
			parameterWriter = new PrintWriter(requestConnection.getOutputStream());
		}
		catch (final IOException exception)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to retrieve output stream for writing to " + destination.toString() + ": " + exception.toString()), callback);
			return;
		}

		parameterWriter.print(parameters);
		parameterWriter.close();

		final int responseCode;
		try
		{
			responseCode = requestConnection.getResponseCode();
		}
		catch (final IOException exception)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to retrieve response code from request to " + destination.toString() + ": " + exception.toString()), callback);
			return;
		}

		if (responseCode != 200)
		{
			try
			{
				final BufferedReader responseReader = new BufferedReader(new InputStreamReader(requestConnection.getErrorStream()));
				String responseLine = responseReader.readLine();

				sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), responseLine), callback);
				return;
			}
			catch (final IOException exception)
			{
				sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to read response error data from request to " + destination.toString() + " with http response " + responseCode + ": " + exception.toString()), callback);
				return;
			}
		}

		final Map<String, String> outputValues = new TreeMap<String, String>();
		try
		{
			final BufferedReader responseReader = new BufferedReader(new InputStreamReader(requestConnection.getInputStream()));
			String responseLine = responseReader.readLine();

			while (responseLine != null)
			{
				String[] keyValuePairs = responseLine.split("&");
				for (final String keyValuePair : keyValuePairs)
				{
					if (!keyValuePair.isEmpty())
					{
						String[] keyAndValue = keyValuePair.split("=");
						if (keyAndValue.length != 2)
						{
							sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unknown data format from response to " + destination.toString() + " with http response " + responseCode + ".  Encountered text was: " + keyValuePair), callback);
							return;
						}

						outputValues.put(URLDecoder.decode(keyAndValue[0], "UTF-8"), URLDecoder.decode(keyAndValue[1], "UTF-8"));
					}
				}

				responseLine = responseReader.readLine();
			}

			responseReader.close();
		}
		catch (final IOException exception)
		{
			sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Failure, new TreeMap<String, String>(), "Unable to read response data from request to " + destination.toString() + " with http response " + responseCode + ": " + exception.toString()), callback);
			return;
		}

		sendResponse(new AuthenticationResponse(AuthenticationResponse.Result.R_Success, outputValues, "Success"), callback);
	}

	private void sendResponse(final AuthenticationResponse response, final AuthenticationRequestCallback callback)
	{
		if (response != null && callback != null && m_gameActivity != null)
		{
			m_gameActivity.runOnUiThread(new Runnable()
			{
				public void run()
				{
					callback.execute(response);
				}
			});
		}
	}

	private final MainActivity m_gameActivity;
}

package sts.game.authentication;

public interface Authenticator
{
	public void authenticate(AuthenticationInterface authenticationInterface, AuthenticationRequest request);
	public void shutdown();

}

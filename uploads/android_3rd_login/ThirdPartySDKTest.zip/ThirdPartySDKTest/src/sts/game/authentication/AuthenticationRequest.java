package sts.game.authentication;

import java.net.URL;
import java.util.Map;

public class AuthenticationRequest
{
	public AuthenticationRequest(final URL destination, final Map<String, String> parameters)
	{
		m_destination = destination;
		m_parameters = parameters;
	}

	public URL getDestination()
	{
		return m_destination;
	}

	public Map<String, String> getParameters()
	{
		return m_parameters;
	}

	public void updateParameter(final String key, final String value)
	{
		m_parameters.put(key, value);
	}

	private final URL m_destination;
	private final Map<String, String> m_parameters;
}

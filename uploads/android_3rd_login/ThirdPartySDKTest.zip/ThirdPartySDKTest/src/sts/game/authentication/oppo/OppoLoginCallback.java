package sts.game.authentication.oppo;

public interface OppoLoginCallback {
	public void onSuccess(String userId, String accessToken);
	public void onFailure();
}

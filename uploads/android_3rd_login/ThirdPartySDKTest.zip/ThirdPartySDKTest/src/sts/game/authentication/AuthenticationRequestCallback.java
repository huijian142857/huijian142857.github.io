package sts.game.authentication;

public interface AuthenticationRequestCallback
{
	public void execute(AuthenticationResponse response);
}

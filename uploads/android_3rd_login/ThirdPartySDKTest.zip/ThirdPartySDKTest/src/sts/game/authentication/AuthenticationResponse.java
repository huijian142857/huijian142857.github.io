package sts.game.authentication;

import java.util.Map;
import java.util.UUID;

public class AuthenticationResponse
{
	private static final String ms_authenticationTokenResponseKey = "authenticationToken";
	
	public enum Result
	{
		R_Success,
		R_Failure
	}

	public AuthenticationResponse(final Result result, final Map<String, String> responseValues, final String resultMessage)
	{
		m_responseValues = responseValues;

		if (result == Result.R_Success)
		{
			final String authenticationTokenString = responseValues.get(ms_authenticationTokenResponseKey);
			UUID authenticationToken = null;
			try
			{
				authenticationToken = UUID.fromString(authenticationTokenString);
			}
			catch (final IllegalArgumentException exception)
			{
				m_authenticationToken = null;
				m_result = Result.R_Failure;
				m_resultMessage = "Invalid authentication token retrieved from authentication response.";
				return;
			}

			m_authenticationToken = authenticationToken;
		}
		else
		{
			m_authenticationToken = null;
		}

		m_result = result;
		m_resultMessage = resultMessage;
	}

	public Result getResult()
	{
		return m_result;
	}

	public UUID getAuthenticationToken()
	{
		return m_authenticationToken;
	}

	public Map<String, String> getValues()
	{
		return m_responseValues;
	}

	public String getResultMessage()
	{
		return m_resultMessage;
	}

	private final Result m_result;
	private final UUID m_authenticationToken;
	private final Map<String, String> m_responseValues;
	private final String m_resultMessage;
}

package sts.game.authentication;

import java.net.URL;
import java.util.Map;
import java.util.TreeMap;

import sts.game.MainActivity;
import sts.game.authentication.oppo.OppoAuthenticator;
import sts.game.authentication.spacetime.SpacetimeAuthenticator;
import android.util.Log;

public class AuthenticationManager
{
	public AuthenticationManager(final MainActivity gameActivity)
	{
		m_authenticationInterface = new GameAuthenticationInterface(gameActivity);
		m_authenticators = new TreeMap<String, Authenticator>();
		
		if (gameActivity.isEnabledAuthenticationType("oppo"))
		{
			Log.w("AuthenticationManager", "oppo authenticator initialized");
			m_authenticators.put("oppo", new OppoAuthenticator());
		}
		
		if (gameActivity.isEnabledAuthenticationType("spacetime"))
		{
			Log.w("AuthenticationManager", "spacetime authenticator initialized");
			m_authenticators.put("spacetime", new SpacetimeAuthenticator());
		}
	}

	public void shutdown()
	{
		for (Authenticator authenticator : m_authenticators.values())
		{
			if (authenticator != null)
				authenticator.shutdown();
		}

		m_authenticators.clear();
	}

	public void authenticate(final String authenticatorId, final URL webAddress, final Map<String, String> inputParameters)
	{
		final Authenticator authenticator = m_authenticators.get(authenticatorId);
		if (authenticator == null)
		{
			Log.w("AuthenticationManager", "authenticate called on uninitialized authenticator(" + authenticatorId + ")");
			m_authenticationInterface.onAuthenticationFailure("authentication is null");
			return;
		}

		final AuthenticationRequest request = new AuthenticationRequest(webAddress, inputParameters);
		authenticator.authenticate(m_authenticationInterface, request);
	}

	private final Map<String, Authenticator> m_authenticators;
	private final GameAuthenticationInterface m_authenticationInterface;
}

package sts.game.authentication;

import java.util.UUID;

public interface AuthenticationInterface
{
	public void sendRequest(AuthenticationRequest request, AuthenticationRequestCallback callback);
	public void onAuthenticationSuccess(final UUID token);
	public void onAuthenticationFailure(final String resultMessage);
	public void onAuthenticationCancel();
}

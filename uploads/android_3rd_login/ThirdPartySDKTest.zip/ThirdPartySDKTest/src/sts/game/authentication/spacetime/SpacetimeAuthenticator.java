package sts.game.authentication.spacetime;

import sts.game.authentication.AuthenticationInterface;
import sts.game.authentication.AuthenticationRequest;
import sts.game.authentication.AuthenticationRequestCallback;
import sts.game.authentication.AuthenticationResponse;
import sts.game.authentication.Authenticator;

public class SpacetimeAuthenticator implements Authenticator
{
	public SpacetimeAuthenticator()
	{
		
	}

	@Override
	public void shutdown()
	{
		
	}

	@Override
	public void authenticate(final AuthenticationInterface authenticationInterface, final AuthenticationRequest request)
	{
		authenticationInterface.sendRequest(request, new AuthenticationRequestCallback()
		{
			public void execute(final AuthenticationResponse response)
			{
				if (response.getResult() == AuthenticationResponse.Result.R_Success)
				{
					authenticationInterface.onAuthenticationSuccess(response.getAuthenticationToken());
				}
				else
				{
					authenticationInterface.onAuthenticationFailure(response.getResultMessage());
				}
			}
		});
	}
}

package sts.game.oppo;

import java.util.Map;

import sts.game.MainActivity;
import sts.game.ThirdPartyClientInterface;
import sts.game.authentication.oppo.OppoLoginCallback;

import com.nearme.gamecenter.open.api.ApiCallback;
import com.nearme.gamecenter.open.api.GameCenterSDK;

public class OppoClientHelper implements ThirdPartyClientInterface {

	private MainActivity mainActivity;
	private OppoLoginCallback m_loginCallback;
	
	private static class SingletonHolder{
		private final static OppoClientHelper instance = new OppoClientHelper();
	}
	
	private OppoClientHelper() {}
	
	public static OppoClientHelper getInstance(){
		return SingletonHolder.instance;
	}
	
	@Override
	public void setMainActivity(MainActivity activity) {
		mainActivity = activity;
	}
	
	public void setLoginCallback(OppoLoginCallback callback)
	{
		m_loginCallback = callback;
	}

	@Override
	public void sdkInit() {
		
	}
	
	public void sdkLogin(){
		GameCenterSDK.getInstance().doLogin(new ApiCallback() {
			@Override
			public void onSuccess(String content, int code) {
				m_loginCallback.onSuccess("userId", "accessToken");
			}

			@Override
			public void onFailure(String content, int code) {
				m_loginCallback.onFailure();
			}
		}, mainActivity);
	}
	
	@Override
	public void sdkSubmitExtendData(Map<String, Object> jsonObject) {
		
	}

	@Override
	public void sdkShowFloatButton(final boolean visible) {
		mainActivity.runOnUiThread(new Runnable(){
			@Override
			public void run() {
				
			}
		});
	}
}

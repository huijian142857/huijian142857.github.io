package sts.game;

import java.util.Map;

public interface ThirdPartyClientInterface {
	public void setMainActivity(final MainActivity activity);
	public void sdkInit();
	public void sdkSubmitExtendData(Map<String, Object> jsonObject);
	public void sdkShowFloatButton(final boolean visible);
}

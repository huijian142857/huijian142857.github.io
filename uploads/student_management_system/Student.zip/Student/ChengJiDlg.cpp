// ChengJiDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Student.h"
#include "ChengJiDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChengJiDlg dialog


CChengJiDlg::CChengJiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CChengJiDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChengJiDlg)
	//}}AFX_DATA_INIT
}


void CChengJiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChengJiDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CChengJiDlg, CDialog)
	//{{AFX_MSG_MAP(CChengJiDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChengJiDlg message handlers



BOOL CChengJiDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
// TODO: Add extra initialization here


	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

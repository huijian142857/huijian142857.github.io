#if !defined(AFX_STUCHECKINFO_H__CBCE6322_77A0_40A6_B098_6F39AFD90A32__INCLUDED_)
#define AFX_STUCHECKINFO_H__CBCE6322_77A0_40A6_B098_6F39AFD90A32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StuCheckInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStuCheckInfo dialog

class CStuCheckInfo : public CDialog
{
// Construction
public:
	CStuCheckInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStuCheckInfo)
	enum { IDD = IDD_DIALOG_StuCheckInfo };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStuCheckInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStuCheckInfo)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STUCHECKINFO_H__CBCE6322_77A0_40A6_B098_6F39AFD90A32__INCLUDED_)

// StuBasicInfo.cpp : implementation file
//

#include "stdafx.h"
#include "Student.h"
#include "StuBasicInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CString scon ="Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=Student";

/////////////////////////////////////////////////////////////////////////////
// CStuBasicInfo dialog


CStuBasicInfo::CStuBasicInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CStuBasicInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStuBasicInfo)
	m_1 = _T("");
	m_10 = _T("");
	m_11 = _T("");
	m_12 = _T("");
	m_13 = _T("");
	m_14 = _T("");
	m_15 = _T("");
	m_16 = _T("");
	m_17 = _T("");
	m_18 = _T("");
	m_19 = _T("");
	m_2 = _T("");
	m_20 = _T("");
	m_21 = _T("");
	m_22 = _T("");
	m_3 = _T("");
	m_4 = _T("");
	m_5 = _T("");
	m_6 = _T("");
	m_7 = _T("");
	m_8 = _T("");
	m_9 = _T("");
	//}}AFX_DATA_INIT
}


void CStuBasicInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStuBasicInfo)
	DDX_Control(pDX, IDC_BUTTON_ModifyOK, m_modifyOK);
	DDX_Control(pDX, IDC_LIST1, m_list);
	DDX_Text(pDX, IDC_EDIT1, m_1);
	DDX_Text(pDX, IDC_EDIT10, m_10);
	DDX_Text(pDX, IDC_EDIT11, m_11);
	DDX_Text(pDX, IDC_EDIT12, m_12);
	DDX_Text(pDX, IDC_EDIT13, m_13);
	DDX_Text(pDX, IDC_EDIT14, m_14);
	DDX_Text(pDX, IDC_EDIT15, m_15);
	DDX_Text(pDX, IDC_EDIT16, m_16);
	DDX_Text(pDX, IDC_EDIT17, m_17);
	DDX_Text(pDX, IDC_EDIT18, m_18);
	DDX_Text(pDX, IDC_EDIT19, m_19);
	DDX_Text(pDX, IDC_EDIT2, m_2);
	DDX_Text(pDX, IDC_EDIT20, m_20);
	DDX_Text(pDX, IDC_EDIT21, m_21);
	DDX_Text(pDX, IDC_EDIT22, m_22);
	DDX_Text(pDX, IDC_EDIT3, m_3);
	DDX_Text(pDX, IDC_EDIT4, m_4);
	DDX_Text(pDX, IDC_EDIT5, m_5);
	DDX_Text(pDX, IDC_EDIT6, m_6);
	DDX_Text(pDX, IDC_EDIT7, m_7);
	DDX_Text(pDX, IDC_EDIT8, m_8);
	DDX_Text(pDX, IDC_EDIT9, m_9);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStuBasicInfo, CDialog)
	//{{AFX_MSG_MAP(CStuBasicInfo)
	ON_BN_CLICKED(IDC_BUTTON_Add, OnBUTTONAdd)
	ON_BN_CLICKED(IDC_BUTTON_Cancel, OnBUTTONCancel)
	ON_BN_CLICKED(IDC_BUTTON_Del, OnBUTTONDel)
	ON_BN_CLICKED(IDC_BUTTON_Clear, OnBUTTONClear)
	ON_BN_CLICKED(IDC_BUTTON_Modify, OnBUTTONModify)
	ON_BN_CLICKED(IDC_BUTTON_ModifyOK, OnBUTTONModifyOK)
	ON_BN_CLICKED(IDC_BUTTON_Search, OnBUTTONSearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStuBasicInfo message handlers

BOOL CStuBasicInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_list.ModifyStyle(7,LVS_REPORT);
	m_list.SetExtendedStyle(LVS_EX_GRIDLINES|LVS_EX_FULLROWSELECT);
	m_list.InsertColumn(0,"ѧ��",LVCFMT_LEFT,150);
	m_list.InsertColumn(1,"����",LVCFMT_LEFT,130);
	m_list.InsertColumn(2,"�Ա�",LVCFMT_LEFT,60);
	m_list.InsertColumn(3,"��������",LVCFMT_LEFT,80);
	m_list.InsertColumn(4,"����",LVCFMT_LEFT,80);
	m_list.InsertColumn(5,"����",LVCFMT_LEFT,90);
	m_list.InsertColumn(6,"������ò",LVCFMT_LEFT,120);
	m_list.InsertColumn(7,"��Դ����",LVCFMT_LEFT,180);
	m_list.InsertColumn(8,"������",LVCFMT_LEFT,230);
	m_list.InsertColumn(9,"ѧԺ",LVCFMT_LEFT,180);	
	m_list.InsertColumn(10,"רҵ",LVCFMT_LEFT,200);
	m_list.InsertColumn(11,"�����༶",LVCFMT_LEFT,220);
	m_list.InsertColumn(12,"ѧ��",LVCFMT_LEFT,70);
	m_list.InsertColumn(13,"��ѧʱ��",LVCFMT_LEFT,100);
	m_list.InsertColumn(14,"��ǰ�꼶",LVCFMT_LEFT,100);
	m_list.InsertColumn(15,"����",LVCFMT_LEFT,150);
	m_list.InsertColumn(16,"�����ʼ�",LVCFMT_LEFT,220);
	m_list.InsertColumn(17,"��ϵ�绰",LVCFMT_LEFT,150);
	m_list.InsertColumn(18,"�ʱ�",LVCFMT_LEFT,100);
	m_list.InsertColumn(19,"����֤��",LVCFMT_LEFT,200);
	m_list.InsertColumn(20,"�Ƿ��ҵ",LVCFMT_LEFT,100);
	m_list.InsertColumn(21,"��ҵ����",LVCFMT_LEFT,80);

	Refresh();

	m_modifyOK.EnableWindow(false);

	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CStuBasicInfo::OnBUTTONAdd() 
{
	// TODO: Add your control notification handler code here

	//�������ݿ�,ADO����
	//����m_pConnection�������Ѿ������õ����ӣ�����ʹ��_RecordsetPtr�ӿڵ�Open�����򿪱��ļ�¼��

	_variant_t value;
	CString da;
	da="select * from StudentInfo";
	try
	{
		CoInitialize(NULL);
		m_pConnection.CreateInstance(_uuidof(Connection));
		m_pRecordset.CreateInstance(_uuidof(Recordset));

		m_pConnection->Open((_bstr_t)scon,"","",adModeUnknown);
		m_pRecordset->Open((_bstr_t)da,m_pConnection.GetInterfacePtr(),adOpenDynamic,adLockOptimistic,adCmdText);
	}
	catch (_com_error e)
	{
		MessageBox(e.ErrorMessage());
	}

	//д������
	try
	{
		    UpdateData(true);
			m_pRecordset->MoveLast();
			m_pRecordset->AddNew();

			_variant_t b;
			b.vt=NULL;//��ָ�룬���������ݿ��в���
	
			m_pRecordset->PutCollect("ѧ��",(_variant_t)m_1);	 
			m_pRecordset->PutCollect("����",(_variant_t)m_2);	
			m_pRecordset->PutCollect("�Ա�",(_variant_t)m_3);	
			m_pRecordset->PutCollect("��������",(_variant_t)m_4);	
			m_pRecordset->PutCollect("����",(_variant_t)m_5);	
			m_pRecordset->PutCollect("����",(_variant_t)m_6);			
			m_pRecordset->PutCollect("������ò",(_variant_t)m_7);	 
			m_pRecordset->PutCollect("��Դ����",(_variant_t)m_8);	
			m_pRecordset->PutCollect("������",(_variant_t)m_9);	
			m_pRecordset->PutCollect("ѧԺ",(_variant_t)m_10);	
			m_pRecordset->PutCollect("רҵ",(_variant_t)m_11);	
			m_pRecordset->PutCollect("�����༶",(_variant_t)m_12);		
			m_pRecordset->PutCollect("ѧ��",(_variant_t)m_13); 
			m_pRecordset->PutCollect("��ѧʱ��",(_variant_t)m_14);
			m_pRecordset->PutCollect("��ǰ�꼶",(_variant_t)m_15);	
			m_pRecordset->PutCollect("����",(_variant_t)m_16);
			
			if(m_17 == "")
				m_pRecordset->PutCollect("�����ʼ�",b);
			else
		    	m_pRecordset->PutCollect("�����ʼ�",(_variant_t)m_17);

			if(m_18 == "")
				m_pRecordset->PutCollect("��ϵ�绰",b);
			else
		    	m_pRecordset->PutCollect("��ϵ�绰",(_variant_t)m_18);

			if(m_19 == "")
				m_pRecordset->PutCollect("�ʱ�",b);
			else	
				m_pRecordset->PutCollect("�ʱ�",(_variant_t)m_19);	

			m_pRecordset->PutCollect("����֤��",(_variant_t)m_20);
			m_pRecordset->PutCollect("�Ƿ��ҵ",(_variant_t)m_21);
			     
			if(m_22 == "")
				m_pRecordset->PutCollect("��ҵ����",b);
			else
			    m_pRecordset->PutCollect("��ҵ����",(_variant_t)m_22);


			m_pRecordset->Update();

		
	}
	catch (_com_error e)
	{
		AfxMessageBox(e.ErrorMessage());
	}
	m_list.DeleteAllItems();
	Refresh();

	
}

void CStuBasicInfo::Refresh()
{
	//�������ݿ�,ADO����
	//����m_pConnection�������Ѿ������õ����ӣ�����ʹ��_RecordsetPtr�ӿڵ�Open�����򿪱��ļ�¼��

	_variant_t value;
	CString da;
	da="select * from StudentInfo";
	try
	{
		CoInitialize(NULL);
		m_pConnection.CreateInstance(_uuidof(Connection));
		m_pRecordset.CreateInstance(_uuidof(Recordset));

		m_pConnection->Open((_bstr_t)scon,"","",adModeUnknown);
		m_pRecordset->Open((_bstr_t)da,m_pConnection.GetInterfacePtr(),adOpenDynamic,adLockOptimistic,adCmdText);
	}
	catch (_com_error e)
	{
		MessageBox(e.ErrorMessage());
	}

	//��list�ؼ��г�ʼ��������Ϣ
	try
	{
		if(!m_pRecordset->BOF)
			m_pRecordset->MoveFirst();//��¼ָ���Ƶ���һ�У���һ����¼��
		else
		{
			AfxMessageBox("���ݿ���û�����ݣ�");
			return ;
		}
		
		int count=0;//��¼����
		
		//��listctrl����������
		//���û��������������־adoEOF������GetCollect(�ֶ���)����ȡ��ǰ��¼
		//ָ����ָ���ֶ�ֵ��Ȼ������MoveNext()�����ƶ�����һ����¼λ��
		while(!m_pRecordset->adoEOF)
		{
			value = m_pRecordset->GetCollect("ѧ��");
			m_list.InsertItem(count,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("����");
			m_list.SetItemText(count,1,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("�Ա�");
			m_list.SetItemText(count,2,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("��������");
			m_list.SetItemText(count,3,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("����");
			m_list.SetItemText(count,4,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("����");
			m_list.SetItemText(count,5,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("������ò");
			m_list.SetItemText(count,6,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("��Դ����");
			m_list.SetItemText(count,7,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("������");
			m_list.SetItemText(count,8,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("ѧԺ");
			m_list.SetItemText(count,9,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("רҵ");
			m_list.SetItemText(count,10,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("�����༶");
			m_list.SetItemText(count,11,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("ѧ��");
			m_list.SetItemText(count,12,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("��ѧʱ��");
			m_list.SetItemText(count,13,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("��ǰ�꼶");
			m_list.SetItemText(count,14,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("����");
			m_list.SetItemText(count,15,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("�����ʼ�");
			if(value.vt==VT_NULL)
				m_list.SetItemText(count,16,"");
			else
		     	m_list.SetItemText(count,16,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("��ϵ�绰");
			if(value.vt==VT_NULL)
				m_list.SetItemText(count,17,"");
			else
			    m_list.SetItemText(count,17,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("�ʱ�");
			if(value.vt==VT_NULL)
				m_list.SetItemText(count,18,"");
			else
			    m_list.SetItemText(count,18,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("����֤��");
			m_list.SetItemText(count,19,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("�Ƿ��ҵ");
			m_list.SetItemText(count,20,(LPCSTR)(_bstr_t)value);

			value = m_pRecordset->GetCollect("��ҵ����");
			if(value.vt==VT_NULL)
				m_list.SetItemText(count,21,"");
			else
				m_list.SetItemText(count,21,(LPCSTR)(_bstr_t)value);			

			count++;
			m_pRecordset->MoveNext();
		}
	}
	catch (_com_error e)
	{
		AfxMessageBox(e.ErrorMessage());
	}

}

void CStuBasicInfo::OnBUTTONCancel() 
{
	// TODO: Add your control notification handler code here
   CDialog::OnCancel();
	
}

void CStuBasicInfo::OnBUTTONDel() 
{
	// TODO: Add your control notification handler code here
	//�������ݿ�,ADO����
	//����m_pConnection�������Ѿ������õ����ӣ�����ʹ��_RecordsetPtr�ӿڵ�Open�����򿪱��ļ�¼��

	_variant_t value;
	CString da;
	da="select * from StudentInfo";
	try
	{
		CoInitialize(NULL);
		m_pConnection.CreateInstance(_uuidof(Connection));
		m_pRecordset.CreateInstance(_uuidof(Recordset));

		m_pConnection->Open((_bstr_t)scon,"","",adModeUnknown);
		m_pRecordset->Open((_bstr_t)da,m_pConnection.GetInterfacePtr(),adOpenDynamic,adLockOptimistic,adCmdText);
	}
	catch (_com_error e)
	{
		MessageBox(e.ErrorMessage());
	}

	
   int i,iState;
   int nItemSelected=m_list.GetSelectedCount();//��ѡ������
   int nItemCount=m_list.GetItemCount();//��������

   if(nItemSelected<1)
       return;
   for(i=nItemCount-1;i>=0;i--)
   {
      iState=m_list.GetItemState(i,LVIS_SELECTED);
      if(iState!=0) 
	  {
		try
		{
			m_pRecordset->Move(i);
			m_pRecordset->Delete(adAffectCurrent);
			m_pRecordset->Update();
		}
        catch(_com_error *e)
		{
             AfxMessageBox(e->ErrorMessage());
		}

	  }
	  
   }
   m_list.DeleteAllItems();
   Refresh();

	
}

void CStuBasicInfo::OnBUTTONClear() 
{
	// TODO: Add your control notification handler code here
	m_1="";m_2="";m_3="";m_4="";m_5="";m_6="";m_7="";m_8="";m_9="";m_10="";
	m_11="";m_12="";m_13="";m_14="";m_15="";m_16="";m_17="";m_18="";m_19="";m_20="";
	m_21="";m_22="";
	UpdateData(false);
	
}


int selRow;
void CStuBasicInfo::OnBUTTONModify() 
{
	// TODO: Add your control notification handler code here

	int nItemSelected=m_list.GetSelectedCount();//��ѡ������
	if(nItemSelected<1)
	{
		MessageBox("����ѡ����Ҫ�޸ĵ���Ŀ");
		return;
	}
	if(nItemSelected>1)
	{
		MessageBox("ֻ��ͬʱ�޸�һ��");
		return;
	}
	selRow = m_list.GetNextItem(-1,LVNI_ALL|LVNI_SELECTED);//��ǰѡȡ�к�

	m_1 = m_list.GetItemText(selRow,0);
	m_2 = m_list.GetItemText(selRow,1);
	m_3 = m_list.GetItemText(selRow,2);
	m_4 = m_list.GetItemText(selRow,3);
	m_5 = m_list.GetItemText(selRow,4);
	m_6 = m_list.GetItemText(selRow,5);
	m_7 = m_list.GetItemText(selRow,6);
	m_8 = m_list.GetItemText(selRow,7);
	m_9 = m_list.GetItemText(selRow,8);
	m_10 = m_list.GetItemText(selRow,9);
	m_11 = m_list.GetItemText(selRow,10);
	m_12 = m_list.GetItemText(selRow,11);
	m_13 = m_list.GetItemText(selRow,12);
	m_14 = m_list.GetItemText(selRow,13);
	m_15 = m_list.GetItemText(selRow,14);
	m_16 = m_list.GetItemText(selRow,15);
	m_17 = m_list.GetItemText(selRow,16);
	m_18 = m_list.GetItemText(selRow,17);
	m_19 = m_list.GetItemText(selRow,18);
	m_20 = m_list.GetItemText(selRow,19);
	m_21 = m_list.GetItemText(selRow,20);
	m_22 = m_list.GetItemText(selRow,21);

	UpdateData(false);

	m_modifyOK.EnableWindow(true);

	
}

void CStuBasicInfo::OnBUTTONModifyOK() 
{
	// TODO: Add your control notification handler code here

	// TODO: Add your control notification handler code here
	//�������ݿ�,ADO����
	//����m_pConnection�������Ѿ������õ����ӣ�����ʹ��_RecordsetPtr�ӿڵ�Open�����򿪱��ļ�¼��

	_variant_t value;
	CString da;
	da="select * from StudentInfo";
	try
	{
		CoInitialize(NULL);
		m_pConnection.CreateInstance(_uuidof(Connection));
		m_pRecordset.CreateInstance(_uuidof(Recordset));

		m_pConnection->Open((_bstr_t)scon,"","",adModeUnknown);
		m_pRecordset->Open((_bstr_t)da,m_pConnection.GetInterfacePtr(),adOpenDynamic,adLockOptimistic,adCmdText);
	}
	catch (_com_error e)
	{
		MessageBox(e.ErrorMessage());
	}


	//д������
	try
	{
		    UpdateData(true);
			m_pRecordset->Move(selRow);

			_variant_t b;
			b.vt=NULL;//��ָ�룬���������ݿ��в���
	
			m_pRecordset->PutCollect("ѧ��",(_variant_t)m_1);	 
			m_pRecordset->PutCollect("����",(_variant_t)m_2);	
			m_pRecordset->PutCollect("�Ա�",(_variant_t)m_3);	
			m_pRecordset->PutCollect("��������",(_variant_t)m_4);	
			m_pRecordset->PutCollect("����",(_variant_t)m_5);	
			m_pRecordset->PutCollect("����",(_variant_t)m_6);			
			m_pRecordset->PutCollect("������ò",(_variant_t)m_7);	 
			m_pRecordset->PutCollect("��Դ����",(_variant_t)m_8);	
			m_pRecordset->PutCollect("������",(_variant_t)m_9);	
			m_pRecordset->PutCollect("ѧԺ",(_variant_t)m_10);	
			m_pRecordset->PutCollect("רҵ",(_variant_t)m_11);	
			m_pRecordset->PutCollect("�����༶",(_variant_t)m_12);		
			m_pRecordset->PutCollect("ѧ��",(_variant_t)m_13); 
			m_pRecordset->PutCollect("��ѧʱ��",(_variant_t)m_14);
			m_pRecordset->PutCollect("��ǰ�꼶",(_variant_t)m_15);	
			m_pRecordset->PutCollect("����",(_variant_t)m_16);
			
			if(m_17 == "")
				m_pRecordset->PutCollect("�����ʼ�",b);
			else
		    	m_pRecordset->PutCollect("�����ʼ�",(_variant_t)m_17);

			if(m_18 == "")
				m_pRecordset->PutCollect("��ϵ�绰",b);
			else
		    	m_pRecordset->PutCollect("��ϵ�绰",(_variant_t)m_18);

			if(m_19 == "")
				m_pRecordset->PutCollect("�ʱ�",b);
			else	
				m_pRecordset->PutCollect("�ʱ�",(_variant_t)m_19);	

			m_pRecordset->PutCollect("����֤��",(_variant_t)m_20);
			m_pRecordset->PutCollect("�Ƿ��ҵ",(_variant_t)m_21);
			     
			if(m_22 == "")
				m_pRecordset->PutCollect("��ҵ����",b);
			else
			    m_pRecordset->PutCollect("��ҵ����",(_variant_t)m_22);


			m_pRecordset->Update();

		
	}
	catch (_com_error e)
	{
		AfxMessageBox(e.ErrorMessage());
	}

	m_list.DeleteAllItems();
	Refresh();
	OnBUTTONClear();
	m_modifyOK.EnableWindow(false);

	
}

void CStuBasicInfo::OnBUTTONSearch() 
{
	// TODO: Add your control notification handler code here

	UpdateData(true);
	if(m_1=="")
	{
		MessageBox("������ѧ�Ž��в�ѯ");
		return;
	}
    else
	{
		int nn=m_list.GetItemCount();
		CString str;
		for(int i=0;i<nn;i++)
		{
			str=m_list.GetItemText(i,0);
			str.Replace(" ","");
			m_1.Replace(" ","");
			if(m_1==str)
			{	
			m_1 = m_list.GetItemText(i,0);
	        m_2 = m_list.GetItemText(i,1);
			m_3 = m_list.GetItemText(i,2);
			m_4 = m_list.GetItemText(i,3);
			m_5 = m_list.GetItemText(i,4);
			m_6 = m_list.GetItemText(i,5);
			m_7 = m_list.GetItemText(i,6);
			m_8 = m_list.GetItemText(i,7);
			m_9 = m_list.GetItemText(i,8);
			m_10 = m_list.GetItemText(i,9);
			m_11 = m_list.GetItemText(i,10);
			m_12 = m_list.GetItemText(i,11);
			m_13 = m_list.GetItemText(i,12);
			m_14 = m_list.GetItemText(i,13);
			m_15 = m_list.GetItemText(i,14);
			m_16 = m_list.GetItemText(i,15);
			m_17 = m_list.GetItemText(i,16);
			m_18 = m_list.GetItemText(i,17);
			m_19 = m_list.GetItemText(i,18);
			m_20 = m_list.GetItemText(i,19);
			m_21 = m_list.GetItemText(i,20);
			m_22 = m_list.GetItemText(i,21);

			UpdateData(false);
			return;
			}

		}
		MessageBox("�Ҳ�����¼��");
		OnBUTTONClear();
	}
}
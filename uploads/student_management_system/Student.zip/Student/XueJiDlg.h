#if !defined(AFX_XUEJIDLG_H__36F6D393_C4BF_40BF_AA17_43CA245D94E9__INCLUDED_)
#define AFX_XUEJIDLG_H__36F6D393_C4BF_40BF_AA17_43CA245D94E9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// XueJiDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CXueJiDlg dialog
#include"StuChangeInfo.h"
#include"StuRegInfo.h"
#include"StuLoanInfo.h"

class CXueJiDlg : public CDialog
{
// Construction
public:
	CXueJiDlg(CWnd* pParent = NULL);   // standard constructor
	
	CStuLoanInfo stuloaninfoDlg;
	CStuRegInfo  stureginfoDlg;
	CStuChangeInfo stuchangeinfoDlg;

// Dialog Data
	//{{AFX_DATA(CXueJiDlg)
	enum { IDD = IDD_XueJi_DIALOG };
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CXueJiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CXueJiDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_XUEJIDLG_H__36F6D393_C4BF_40BF_AA17_43CA245D94E9__INCLUDED_)

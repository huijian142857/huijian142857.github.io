#if !defined(AFX_DANGANDLG_H__4F9005BE_AD17_4599_BE55_1B4B7CF3D9FC__INCLUDED_)
#define AFX_DANGANDLG_H__4F9005BE_AD17_4599_BE55_1B4B7CF3D9FC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DangAnDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDangAnDlg dialog

#include "StuBasicInfo.h"
#include "StuCheckInfo.h"
#include "StuFamInfo.h"
#include "StuRPInfo.h"

class CDangAnDlg : public CDialog
{
// Construction
public:
	void Refresh();
	_RecordsetPtr m_pRecordset; //������¼������
	_ConnectionPtr m_pConnection;

	CDangAnDlg(CWnd* pParent = NULL);   // standard constructor

	CStuBasicInfo stubasicinfoDlg;
	CStuCheckInfo stucheckinfoDlg;
	CStuFamInfo   stufaminfoDlg;
	CStuRPInfo   sturpinfoDlg;

// Dialog Data
	//{{AFX_DATA(CDangAnDlg)
	enum { IDD = IDD_DangAn_DIALOG };
	CListCtrl	m_list;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDangAnDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDangAnDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnBUTTONStuBasicInfo();
	afx_msg void OnBUTTONRPInfo();
	afx_msg void OnBUTTONFamInfo();
	afx_msg void OnBUTTONCheckInfo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DANGANDLG_H__4F9005BE_AD17_4599_BE55_1B4B7CF3D9FC__INCLUDED_)

#if !defined(AFX_STUREGINFO_H__691D8F9A_0C10_4AFC_AE6F_C615805266FD__INCLUDED_)
#define AFX_STUREGINFO_H__691D8F9A_0C10_4AFC_AE6F_C615805266FD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StuRegInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStuRegInfo dialog

class CStuRegInfo : public CDialog
{
// Construction
public:
	CStuRegInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStuRegInfo)
	enum { IDD = IDD_DIALOG_StuRegInfo };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStuRegInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStuRegInfo)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STUREGINFO_H__691D8F9A_0C10_4AFC_AE6F_C615805266FD__INCLUDED_)

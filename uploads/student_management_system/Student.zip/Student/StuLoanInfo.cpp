// StuLoanInfo.cpp : implementation file
//

#include "stdafx.h"
#include "Student.h"
#include "StuLoanInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStuLoanInfo dialog


CStuLoanInfo::CStuLoanInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CStuLoanInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStuLoanInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CStuLoanInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStuLoanInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStuLoanInfo, CDialog)
	//{{AFX_MSG_MAP(CStuLoanInfo)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStuLoanInfo message handlers

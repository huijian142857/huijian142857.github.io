// StuChangeInfo.cpp : implementation file
//

#include "stdafx.h"
#include "Student.h"
#include "StuChangeInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStuChangeInfo dialog


CStuChangeInfo::CStuChangeInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CStuChangeInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStuChangeInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CStuChangeInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStuChangeInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStuChangeInfo, CDialog)
	//{{AFX_MSG_MAP(CStuChangeInfo)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStuChangeInfo message handlers

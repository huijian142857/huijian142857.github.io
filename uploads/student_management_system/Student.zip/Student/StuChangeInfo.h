#if !defined(AFX_STUCHANGEINFO_H__5AE818B0_31ED_4409_8900_356F5E361826__INCLUDED_)
#define AFX_STUCHANGEINFO_H__5AE818B0_31ED_4409_8900_356F5E361826__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// StuChangeInfo.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CStuChangeInfo dialog

class CStuChangeInfo : public CDialog
{
// Construction
public:
	CStuChangeInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CStuChangeInfo)
	enum { IDD = IDD_DIALOG_StuChangeInfo };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStuChangeInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CStuChangeInfo)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STUCHANGEINFO_H__5AE818B0_31ED_4409_8900_356F5E361826__INCLUDED_)

// StuFamInfo.cpp : implementation file
//

#include "stdafx.h"
#include "Student.h"
#include "StuFamInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CStuFamInfo dialog


CStuFamInfo::CStuFamInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CStuFamInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStuFamInfo)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CStuFamInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStuFamInfo)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CStuFamInfo, CDialog)
	//{{AFX_MSG_MAP(CStuFamInfo)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStuFamInfo message handlers

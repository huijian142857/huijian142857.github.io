//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Student.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STUDENT_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDD_DangAn_DIALOG               129
#define IDD_XueJi_DIALOG                130
#define IDD_ChengJi_DIALOG              131
#define IDD_User_DIALOG                 132
#define IDD_DIALOG_StuRPInfo            133
#define IDD_DIALOG_StuBasicInfo         134
#define IDD_DIALOG_StuFamInfo           135
#define IDD_DIALOG_StuCheckInfo         136
#define IDD_DIALOG_StuRegInfo           141
#define IDD_DIALOG_StuChangeInfo        142
#define IDD_DIALOG_StuLoanInfo          143
#define IDC_TAB1                        1000
#define IDC_LIST1                       1010
#define IDC_EDIT1                       1011
#define IDC_EDIT2                       1012
#define IDC_BUTTON_RPInfo               1013
#define IDC_EDIT3                       1013
#define IDC_BUTTON_FamInfo              1014
#define IDC_EDIT4                       1014
#define IDC_BUTTON_CheckInfo            1015
#define IDC_EDIT5                       1015
#define IDC_BUTTON_StuBasicInfo         1016
#define IDC_EDIT6                       1016
#define IDC_EDIT7                       1017
#define IDC_EDIT8                       1018
#define IDC_EDIT9                       1019
#define IDC_EDIT10                      1020
#define IDC_EDIT11                      1021
#define IDC_EDIT12                      1022
#define IDC_EDIT13                      1023
#define IDC_EDIT14                      1024
#define IDC_EDIT15                      1025
#define IDC_EDIT16                      1026
#define IDC_EDIT17                      1027
#define IDC_EDIT18                      1028
#define IDC_EDIT19                      1029
#define IDC_EDIT20                      1030
#define IDC_EDIT21                      1031
#define IDC_EDIT22                      1032
#define IDC_BUTTON_Del                  1036
#define IDC_BUTTON_Add                  1037
#define IDC_BUTTON1                     1037
#define IDC_BUTTON_Modify               1038
#define IDC_BUTTON2                     1038
#define IDC_BUTTON_Search               1039
#define IDC_BUTTON3                     1039
#define IDC_BUTTON_Cancel               1040
#define IDC_BUTTON_Clear                1041
#define IDC_BUTTON_ModifyOK             1042

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
